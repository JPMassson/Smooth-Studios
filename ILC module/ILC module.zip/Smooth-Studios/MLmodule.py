import pandas as pd
import numpy as np
from math import log
import matplotlib.pyplot as plt
import operator
import sys

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.metrics import classification_report, accuracy_score

dataset = pd.read_csv('DataCSV.csv')

# dataset.isnull().sum()

# for column in dataset.columns:
#     print(f"{column}: {dataset[column].unique()}")

# unique_values = dataset[['major', 'course level', 'first technical skill', 'second technical skill', 'first non-technical skill', 'second non-technicalskill']].nunique()

# print(unique_values)
# for col in ['major', 'course level', 'first technical skill', 'second technical skill', 'first non-technical skill', 'second non-technicalskill']:
#     value_counts = dataset[col].value_counts()
#     print(f'column name: {col}\n{value_counts}\n')

encoders = {}

for column in ['major', 'course level', 'first technical skill', 'second technical skill', 'first non-technical skill', 'second non-technicalskill']:
    encoders[column] = LabelEncoder()
    dataset[column] = encoders[column].fit_transform(dataset[column])
#print(dataset.head())

X = dataset[['major', 'course level']]
y = dataset[['first technical skill', 'second technical skill', 'first non-technical skill', 'second non-technicalskill']]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

rf = RandomForestClassifier(random_state=42)
multi_target_rf = MultiOutputClassifier(rf, n_jobs=-1)
multi_target_rf.fit(X_train, y_train)


y_pred = multi_target_rf.predict(X_test)


def individual_accuracy(y_true, y_pred):
    return np.mean([accuracy_score(y_true[col], y_pred[:, idx]) for idx, col in enumerate(y_true.columns)])

print("Accuracy Score: ", individual_accuracy(y_test, y_pred))

def print_classification_reports(y_true, y_pred):
    for idx, col in enumerate(y_true.columns):
        print(f"Classification Report for {col}:")
        print(classification_report(y_true[col], y_pred[:, idx]))
        print("\n")

#print_classification_reports(y_test, y_pred)

def recommend_skills(major, course_level):
    input_data = pd.DataFrame([[major, course_level]], columns=['major', 'course level'])

    input_data_encoded = input_data.copy()

    for column in ['major', 'course level']:
        input_data_encoded[column] = encoders[column].transform(input_data[column].values)  # Use the appropriate encoder from the encoders dictionary

    predictions = multi_target_rf.predict(input_data_encoded)
    
    decoded_predictions = []
    for idx, column in enumerate(['first technical skill', 'second technical skill', 'first non-technical skill', 'second non-technicalskill']):
        decoded_predictions.append(encoders[column].inverse_transform([predictions[0][idx]])[0])

    return {
        'first technical skill': decoded_predictions[0],
        'second technical skill': decoded_predictions[1],
        'first non-technical skill': decoded_predictions[2],
        'second non-technical skill': decoded_predictions[3]
    }

major = 'Data Engineering'
course_level = 'professional B'

recommendation = recommend_skills(major, course_level)
print("recommend_skills：")
for skill, value in recommendation.items():
    print(f"{skill}: {value}")
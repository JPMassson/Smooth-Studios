
from flask import Flask, render_template, request, redirect, url_for, abort, jsonify
import json
import os.path
from MLmodule import recommend_skills

app = Flask(__name__)

@app.route('/')
def home(): 
    return render_template('home.html')

@app.route('/your-course', methods=['GET', 'POST'])
def your_course(): 
    # return render_template('your_course.html', course_level=request.form['course_level'] )
    if request.method == 'POST':
        course = {}        
        course[request.form['name']] = {'major': request.form['major'], 'course_level': request.form['course_level'], 'project':request.form['project']}
        
        # major = request.form['major']
        # course_level = request.form['course_level']
        # recommendation = recommend_skills(major, course_level)

        with open('course.json','w') as course_file:
            json.dump(course, course_file)
        return render_template('your_course.html', name=request.form['name'], project=request.form['project'])
    else: 
        return redirect(url_for('home'))
    
@app.route('/<string:name>')
def redirect_to_student(name):
    if os.path.exists('course.json'): 
        with open('course.json') as course_file: 
            course=json.load(course_file)
            if name in course.keys():  
                    major = course[name]['major']
                    course_level = course[name]['course_level']
                    recommendation = recommend_skills(major, course_level)
                    return render_template('student.html',name = name, recommend = recommendation)
            
    return abort(404)

@app.errorhandler(404)
def page_not_found(error): 
    return render_template('page_not_found.html'), 404

@app.route('/resources')
def resource():
    return render_template('resources.html')




